
""" ``caching`` module.
"""

from wheezy.http import response_cache as handler_cache


assert handler_cache
