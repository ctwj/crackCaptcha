
"""
"""

# flake8: noqa

from wheezy.web.authorization import authorize
from wheezy.web.authorization import secure
from wheezy.web.caching import handler_cache


__version__ = '0.1.485'
